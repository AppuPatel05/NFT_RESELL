export enum NFTCategory{
    art="Art",
    gaming = "Gaming"
}