export interface JWTPayload{
    username: string;
}