export enum UserRole{
    User = "User",
    Admin = "Admin"
}